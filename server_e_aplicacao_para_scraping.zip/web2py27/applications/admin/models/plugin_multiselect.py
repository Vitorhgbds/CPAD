response.files.append(
    URL('static', 'plugin_multiselect/jquery.multi-select.js'))
response.files.append(URL('static', 'plugin_multiselect/multi-select.css'))
response.files.append(URL('static', 'plugin_multiselect/start.js'))
