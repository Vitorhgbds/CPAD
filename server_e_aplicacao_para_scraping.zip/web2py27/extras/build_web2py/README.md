# build-web2py

The files in this folder must be run from the main web2py folder.
They are for building windows and osx binary distribution using PyInstaller and not meant for the end user.
